HARSH AI STUDIO
================

This is a single-file static website.

Vercel:
1. Go to vercel.com and sign in.
2. Choose Add New -> Project.
3. Import/upload the project.
4. Deploy.
5. Your free vercel.app URL will be generated.

No API key is required for this starter version.
The generators are browser-based prompt generators, not real cloud AI generation.
